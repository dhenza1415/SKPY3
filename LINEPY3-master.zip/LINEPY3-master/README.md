# Introduction
Haaiii semuaaa! terutama untuk warga line,<br>
git ini bertujuan untuk membantu kalian yg bingung bagaimana memakai <b>[line-py](https://github.com/fadhiilrachman/line-py)</b>, maka dari itu dimasukkan sedikit fungsi agar kalian pahami. setelah paham jangan sombong Ya apalagi mengakui hak ciptra orang ^_^
# Installation
- VPS Ubuntu
1. pip install python3-pip<br>
2. pip3 install rsa<br>
3. pip3 install PyQRCode<br>
4. pip3 install requests<br>
5. and other required<br><br>
# Notes
1. Jika os selain ubuntu bisa kalian sesuaikan sendiri<br>
2. Silahkan ubah User-agen di <b>LINEPY/config.py</b> <b>(</b>default UA : IOS\t7.14.0\tiPhone OS\t10.12.0<b>)</b><br>
## Author
Fadhiil Rachman / [@fadhiilrachman](https://github.com/fadhiilrachman/line-py)

